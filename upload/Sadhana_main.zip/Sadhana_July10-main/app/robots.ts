import type { MetadataRoute } from "next";

/**
 * robots.txt — points crawlers at the sitemap and blocks API/internal
 * routes from indexing. Complements app/sitemap.ts for SEO.
 */

const BASE_URL =
  process.env.NEXT_PUBLIC_SITE_URL?.replace(/\/$/, "") ??
  "https://astrokalki.example.com";

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      {
        userAgent: "*",
        allow: "/",
        disallow: ["/api/"],
      },
    ],
    sitemap: `${BASE_URL}/sitemap.xml`,
  };
}
