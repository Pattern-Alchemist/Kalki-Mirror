---
title: Stambhana-karma
category: Tantra
subcategory: "Ṣaṭ-karma (immobilization / paralysis)"
tradition: Śākta-Śaiva Tantra (Mantramārga / Kaula)
language: "Sanskrit + Hindi"
century: "Medieval (c. 7th–14th c.); commentarial tradition to 18th c."
tags: [shat-karma, stambhana, immobilization, paralysis, abhicara, ugra, mantra-shastra]
caution_level: high
source: "Web-researched, scholarly attested"
---

# Stambhana Karma

> The third of the six ṣaṭ-karma — the immobilisation (*stambhana*) rite for arresting motion, speech, or intent in a target. High caution — an *ugra*-category ṣaṭ-karma that paralyzes a hostile force's capacity to act. Distinct from the Bagalāmukhī Mahāvidyā sādhana (the goddess-form whose signature operation is stambhana); here stambhana is catalogued as the standalone ṣaṭ-karma category. Preserved here as heritage / source material. Not instructional.

---

## I. Textual Attestation

- **Primary text:** *Agni Purāṇa* chapter 138 ("The six accessory acts relating to all Mantras", *ṣaṭkarman*); *Prapañcasāra Tantra* (attributed to Śaṅkarācārya, c. 8th–9th c., Avalon ed., Tantric Texts Series 18, 1919); *Mahānirvāṇa Tantra* Chapter VIII (Avalon / Woodroffe, 1913, where the stone *kalāśa* is specified for *stambhana*); *Śāradā Tilaka Tantram* of Lakṣmaṇa Deśikendra with the *Padārthādarśa* of Rāghavabhaṭṭa; *Todala Tantra* (the Śākta tantra that lists the Mahāvidyā-residencies of the six ṣaṭ-karma, with Bagalāmukhī as the presiding deity of stambhana).
- **Secondary text(s):** *Kālīvilāsa Tantra* (ed. Parvatīcaraṇa Tarkatīrtha); *Brahmayāmala / Picumata* (Hatley 2018 critical edition); *Kubjikāmatatantra* and *Ṣaṭsāhasrasaṃhitā*; *Rasaratnākara* of Nityanātha Siddha (13th c.); *Mantra Mahodadhi* of Mahīdhara; *Bagalāmukhī Rahasya* (Pitāmbarā Peeth 1964, archive.org) — the goddess-form paddhati whose operation overlaps the standalone ṣaṭ-karma category.
- **Key scholarship:** Teun Goudriaan and Sanjukta Gupta, *Hindu Tantric and Śākta Literature* (Harrassowitz, 1981); Alexis Sanderson, "The Śaiva Age" (in Einoo ed., 2009); David Gordon White, *Kiss of the Yoginī* (Chicago, 2003); Sir John Woodroffe, *Shakti and Shâkta* (1929).
- **Source URL:**
  - Wisdom Library entry on the six accessory acts (Agni Purāṇa ch. 138): https://www.wisdomlib.org/hinduism/book/the-agni-purana/d/doc1083368.html
  - Wisdom Library "Satkarman" definition page: https://www.wisdomlib.org/definition/satkarman
  - *Prapañcasāra Tantra* (Avalon ed., Tantric Texts Series 18, 1919), Internet Archive: https://archive.org/details/czkn_tantric-texts-series-18-prapanchasara-tantra-of-shankaracharya-vol-1-arthur-aval
  - *Mahānirvāṇa Tantra* (Avalon / Woodroffe, 1913, Aghori.it full text): https://www.aghori.it/mahanirvana_tantra.htm
  - *Mahānirvāṇa Tantra*, sacred-texts.com: https://sacred-texts.com/tantra/maha/index.htm
  - *Śāradā Tilaka Tantram*, ed. Sudhakar Malaviya, Internet Archive: https://archive.org/details/SharadaTilakaTantramISudhakarMalaviya
  - *Śāradā Tilaka Tantra* (Avalon 1933, Tantric Texts Series 16), PDF: https://www.holybooks.com/wp-content/uploads/Tantric-Texts-Series-16-Sarada-Tilaka-Tantra-Part-1-Arthur-Avalon-1933.pdf
  - *Todala Tantra*, Internet Archive (2024 Devanagari upload): https://archive.org/details/todala-tantra
  - *Kālīvilāsa Tantra* (Tarkatīrtha ed.), Internet Archive: https://archive.org/details/kalivilasatantra00prvauoft
  - *Shakti and Shâkta* (Woodroffe 1929), Internet Archive: https://archive.org/details/in.ernet.dli.2015.217317
  - *Hindu Tantric and Śākta Literature* (Goudriaan & Gupta 1981), PDF: https://ia801405.us.archive.org/0/items/in.ernet.dli.2015.202751/2015.202751.Hindu-Tantric.pdf
  - Sanderson, "The Śaiva Age" (2009), PDF: https://telibrary.com/wp-content/uploads/2022/09/Saiva-Ages-by-Sanderson.pdf

The *Agni Purāṇa* ch. 138 (Wisdom Library translation) catalogues *stambhana* as the third of the *ṣaṭ-karma*, immediately after vaśīkaraṇa. The *Prapañcasāra Tantra* (Avalon 1919 edition) preserves the operative *stambhana* paddhati within its mantra-śāstra frame; Shastra Deep's essay on *Prapañcasāra* explicitly enumerates "stambhana (immobilizing)" as the third of the six. The Wisdom Library "Satkarman" definition page records that the *Ṣaṭsāhasrasaṃhitā* and the *Rasaratnākara* both catalogue the same six operations in the same order.

The *Mahānirvāṇa Tantra* Chapter VIII (Avalon/Woodroffe English translation, preserved in the Aghori.it full-text mirror and on sacred-texts.com) prescribes the stone (*pāṣāṇa*) kalāśa specifically for *stambhana* — distinct from the crystal (*sphaṭika*) kalāśa for vaśīkaraṇa, the clay (*mṛt*) kalāśa for all-purposes-and-śānti, and other prescriptions for vidveṣaṇa, uccāṭana, and māraṇa. The stone-medium — the dense, motionless, hard mineral — is the ritual signature of stambhana's intent to "petrify" or freeze the target's capacity to act. This kalāśa-specification is one of the most cited single-text witnesses of the operational distinction among the six ṣaṭ-karma.

The *Todala Tantra* — preserved in a 2024 Devanagari upload on the Internet Archive (archive.org/details/todala-tantra) — lists the presiding Mahāvidyā of each of the six ṣaṭ-karma: this is the canonical Śākta enumeration by which Bagalāmukhī is the presiding deity of *stambhana*. The standalone stambhana-ṣaṭ-karma is therefore textually distinct from the Bagalāmukhī Mahāvidyā sādhana (catalogued separately in *bagalamukhi-sadhana.md* in this archive): the ṣaṭ-karma category may be performed with any dīkṣā-mantra per the *Agni Purāṇa* ch. 138 frame, while the Bagalāmukhī sādhana uses the Bagalāmukhī mūla-mantra specifically.

The *Śāradā Tilaka Tantram* (Lakṣmaṇa Deśikendra, c. 10th–11th c., with Rāghavabhaṭṭa's *Padārthādarśa* commentary) preserves the stambhana-mantra formulations within the text's wider pūjā-prakaraṇa. Sanderson (2009) documents the *ṣaṭ-karma* framework — with stambhana as the third operation — as a defining feature of the Mantramārga Śaiva-Śākta corpus from the 7th–8th c. onward. White (2003) discusses the ṣaṭ-karma within the broader Kāpālika-Kaula ritual matrix from which the medieval Śaiva-Śākta ṣaṭ-karma textual tradition emerges.

---

## II. The Category (per sources)

Stambhana-karma is the third of the six ṣaṭ-karma and the second of the five *ugra* (fierce) operations. The etymology is from *stambha* ("paralysis, petrification") + *karaṇa* ("the act of"); the rite arrests motion, speech, or intent in a target. The *Mahānirvāṇa Tantra* Ch. VIII distinguishes stambhana from the other ṣaṭ-karma by the kalāśa-material prescription: *pāṣāṇa* (stone), the dense motionless mineral, is the signature medium of stambhana — in contrast to the *sphaṭika* (crystal) of vaśīkaraṇa, the *mṛt* (clay) of śānti-and-all-purposes, and so on. The stone-medium signals the rite's intent to "petrify" the target's capacity to act.

The Shastra Deep essay on *Prapañchasāra* confirms that the *Prapañchasāra Tantra* enumerates stambhana as the third of the six, immediately after vaśīkaraṇa and immediately before vidveṣaṇa — positioning stambhana as the second of the *ugra*-series. The textual tradition consistently frames stambhana as a *motion-arrest* operation: where vaśīkaraṇa bends the target's will toward the practitioner, stambhana simply freezes the target's capacity to move, speak, or act on their will — the target retains their will but cannot execute it. This is the key operational distinction from vaśīkaraṇa.

Woodroffe (1929, *Shakti and Shâkta*) frames stambhana within the broader *abhicāra* category but distinguishes the immobilisation-rite from the more destructive ṣaṭ-karma (vidveṣaṇa, uccāṭana, māraṇa) by noting that stambhana produces a *suspension* of capacity rather than a destruction — the target remains alive, present, and conscious, but cannot enact the hostile intent. The *Todala Tantra* assigns the Bagalāmukhī Mahāvidyā as the presiding deity of stambhana, indicating that the Mahāvidyā-form is the paradigmatic stambhana-śakti within the Śākta tradition — but the *Agni Purāṇa* ch. 138 frame confirms that the standalone ṣaṭ-karma category may be performed with any dīkṣā-mantra, making stambhana-karma a general ritual category distinct from the specific Bagalāmukhī sādhana.

The *Brahmayāmala / Picumata* — a Śaiva-Śākta tantra of c. 7th–8th c. (Hatley 2018 critical edition) — preserves early attestations of the stambhana operation within the Vidyāpīṭha textual corpus, providing the textual-archaeological evidence that stambhana as a ṣaṭ-karma predates its specific association with Bagalāmukhī in the later Mahāvidyā system.

---

## III. Mantra & Method (as documented in sources)

> **Editorial note.** The mantra-forms and counts below are documented from published textual sources for scholarly preservation. This is documentation, not instruction.

- **Bīja mantra:** The *Agni Purāṇa* ch. 138 frame attaches the ṣaṭ-karma operations to "all Mantras" — the practitioner's own dīkṣā-mantra, with the stambhana operation specified by add-on bījas and the *stambhana-nyāsa*. The specific *stambhana-bīja* cited in the *Śāradā Tilaka* paddhati and in the *Mantra Mahodadhi* of Mahīdhara is dīkṣā-restricted in published editions; the per-recension exact form is not reproduced here. The Bagalāmukhī-paddhati tradition uses the *hlīṁ* bīja as the stambhana-bīja par excellence (the "paralyser-bīja"), but the standalone ṣaṭ-karma category allows operation with any dīkṣā-mantra per the *Agni Purāṇa* frame.
- **Mantra count:** The *Prapañcasāra* paddhati and the *Śāradā Tilaka* commentarial tradition document puraścaraṇa counts in multiples of 100,000; the *Mantra Mahodadhi* records the stambhana-specific count.
- **Duration:** Cycles of 7, 21, or 41 days are documented in the Śāradā Tilaka paddhati.
- **Direction facing:** South or South-west per paddhati convention for *ugra*-rites; the *Mahānirvāṇa Tantra* Ch. VIII specifies the kalāśa placement for stambhana with the appropriate orientation.
- **Kalāśa material:** *Pāṣāṇa* (stone) per *Mahānirvāṇa Tantra* Ch. VIII — the canonical single-text witness for the stambhana-rite's signature material.

The procedure documented in the *Agni Purāṇa* ch. 138 (per Wisdom Library's translation) frames stambhana as the third ṣaṭ-karma operation, performed after the standard *ṣaḍaṅga-nyāsa*, *dig-bandhana*, and *guru-pūjā* preliminaries. The practitioner establishes the stone *kalāśa* (per *Mahānirvāṇa Tantra* Ch. VIII), performs *japa* of the operative mantra with the stambhana-bīja prefixed, and conducts a *homa* with *dense / heavy / bitter* offerings (mustard-oil, *nimba* leaves, salt, dark *tila*). The *Śāradā Tilaka* paddhati documents the application of the *stambhana-nyāsa* on the practitioner's own body prior to the operation.

The *Mantra Mahodadhi* of Mahīdhara (17th c.) reproduces multiple stambhana-formulations from the Śaiva-Śākta corpus; the per-recension exact forms are dīkṣā-restricted in the published editions. The Bagalāmukhī-paddhati tradition (the *Bagalāmukhī Rahasya* of Pitāmbarā Peeth, 1964) documents the stambhana-operation as the paradigmatic application of the *hlīṁ* bīja — but as noted, the *Agni Purāṇa* ch. 138 frame confirms that the standalone ṣaṭ-karma category may be performed with any dīkṣā-mantra, not exclusively with the Bagalāmukhī mūla-mantra.

---

## IV. Yantra (if attested)

A stambhana-specific yantra is documented in the *Mantra Mahodadhi* of Mahīdhara and in the Śāradā Tilaka paddhati tradition: a square *bhūpura* with four cardinal gates, an eight-petalled lotus ring, and a central downward-pointing *tri-koṇa* (yoni-triangle) housing the stambhana-bīja at its bindu. The *Śāradā Tilaka* paddhati documents the application of this yantra inscribed on *bhūrja* (birch-bark) or *tāṭi* (palm-leaf) using a paste of *kuṅkuma*, *gorocanā*, and *pāṣāṇa-cūrṇa* (stone-powder, consistent with the *Mahānirvāṇa Tantra* kalāśa-signature). The target's name is inscribed within the *tri-koṇa* around the bīja. The Bagalāmukhī-yantra form — catalogued separately in *bagalamukhi-sadhana.md* — is the paradigmatic Mahāvidyā-form of this yantra, but the standalone ṣaṭ-karma category permits operation with the practitioner's own dīkṣā-devatā's yantra with the stambhana-bīja installed in the central bindu. Specific bīja placements are dīkṣā-restricted in the published editions and are not reproduced here.

---

## V. Warnings and Contraindications (per sources)

- The *Śāradā Tilaka* paddhati, the *Prapañcasāra* commentary of Padmapāda, and the *Mantra Mahodadhi* of Mahīdhara all restrict the operative stambhana-mantra to practitioners who have received the relevant dīkṣā in an authorised lineage.
- Woodroffe (1929) classifies stambhana within the broader *abhicāra* category and warns that the *ugra*-ṣaṭ-karma are subject to the *kāmya*-rite cautions of *Mahānirvāṇa Tantra* Ch. VIII, which restricts their performance to those who have completed the Kaula-dīkṣā and observe the *pañca-tattva* frame.
- Sanderson (2009, "The Śaiva Age") documents the Śaiva-Śākta textual tradition's caution that ṣaṭ-karma performed without correct *mantra-siddhi* rebounds on the practitioner: the textual witnesses describe this as *mantra-vyāghāta* (mantra-collision), in which the ungrounded practitioner's own capacity to act is arrested by the operation intended for the target.
- The *Brahmayāmala* / *Picumata* (Hatley 2018 critical edition, chapters 1–2, 39–40, 83) documents the early Śaiva-Śākta tradition's warning that stambhana-operations on one's guru, on a brāhmaṇa, or on a kinsman are explicitly prohibited and result in the practitioner's own paralysis — both physical and energetic.
- The standalone stambhana ṣaṭ-karma (this category) should be carefully distinguished from the Bagalāmukhī Mahāvidyā sādhana (catalogued in *bagalamukhi-sadhana.md*): the Mahāvidyā-form uses the Bagalāmukhī mūla-mantra specifically and culminates in the unified goddess-sādhana of the eighth Daśa-Mahāvidyā, while the standalone ṣaṭ-karma is a general ritual category attachable to any dīkṣā-mantra per the *Agni Purāṇa* ch. 138 frame.

---

## VI. Bibliography

1. Goudriaan, Teun, and Sanjukta Gupta. *Hindu Tantric and Śākta Literature.* Wiesbaden: Otto Harrassowitz, 1981. (PDF: https://ia801405.us.archive.org/0/items/in.ernet.dli.2015.202751/2015.202751.Hindu-Tantric.pdf)
2. Sanderson, Alexis. "The Śaiva Age." In Einoo ed., *Genesis and Development of Tantrism.* Tokyo, 2009, pp. 41–350. (PDF: https://telibrary.com/wp-content/uploads/2022/09/Saiva-Ages-by-Sanderson.pdf)
3. White, David Gordon. *Kiss of the Yoginī: "Tantric Sex" in its South Asian Contexts.* Chicago: University of Chicago Press, 2003. (Semantic Scholar: https://www.semanticscholar.org/paper/Kiss-of-the-Yogini%3A-%22Tantric-Sex%22-in-its-South-White/eab95d9efa2a13a9e18a18e1d5c3a78972e96b52)
4. Woodroffe, Sir John (Arthur Avalon). *Shakti and Shâkta.* Madras: Ganesh & Co., 1929. (Internet Archive: https://archive.org/details/in.ernet.dli.2015.217317)
5. Avalon, Arthur (ed. and trans.). *The Great Liberation (Mahānirvāṇa Tantra).* Calcutta, 1913. (Aghori.it: https://www.aghori.it/mahanirvana_tantra.htm; sacred-texts.com: https://sacred-texts.com/tantra/maha/index.htm; Internet Archive: https://archive.org/details/in.ernet.dli.2015.65843)
6. Avalon, Arthur (ed. and trans.). *Prapañchasára Tantra of Śankaráchárya*, vol. 1 (Tantric Texts Series 18). Calcutta, 1919. (Internet Archive: https://archive.org/details/czkn_tantric-texts-series-18-prapanchasara-tantra-of-shankaracharya-vol-1-arthur-aval)
7. *Śāradā Tilaka Tantram* of Lakṣmaṇa Deśikendra, ed. Sudhakar Malaviya. (Internet Archive: https://archive.org/details/SharadaTilakaTantramISudhakarMalaviya)
8. *Śāradā Tilaka Tantra*, Part 1 (Tantric Texts Series 16, Arthur Avalon, 1933). (PDF: https://www.holybooks.com/wp-content/uploads/Tantric-Texts-Series-16-Sarada-Tilaka-Tantra-Part-1-Arthur-Avalon-1933.pdf)
9. *Todala Tantra*, Internet Archive (2024 Devanagari upload): https://archive.org/details/todala-tantra
10. *Kālīvilāsa Tantra*, ed. Parvatīcaraṇa Tarkatīrtha. (Internet Archive: https://archive.org/details/kalivilasatantra00prvauoft)
11. Hatley, Shaman. *The Brahmayāmalatantra or Picumata, vol. 1: Chapters 1–2, 39–40, & 83.* Pondicherry: Institut Français de Pondichéry, 2018. (Hatley 2007 PhD thesis PDF: https://blog.umamaya.com/wp-content/uploads/2018/12/Hatley-Brahmayamala-Thesis-2007.pdf)
12. *Agni Purāṇa* ch. 138, Wisdom Library: https://www.wisdomlib.org/hinduism/book/the-agni-purana/d/doc1083368.html
13. Wisdom Library "Satkarman" definition page: https://www.wisdomlib.org/definition/satkarman
14. Mahīdhara. *Mantra Mahodadhi.* (Mumbai: Khemraj Shrikrishnadas, multiple reprints.)
15. Shastra Deep, "Prapañcasāra Tantra: Essence of the Universe": https://shastradeep.com/agamas-tantras/shakta-agamas-tantras/prapanchasara

---

## Editorial Framing

This document is preserved as part of the AstroKalki knowledge archive for scholarly study. It does not prescribe, recommend, or guarantee outcomes. Readers seeking to undertake the described practice should consult qualified lineage holders and the primary texts directly. The AstroKalki project does not endorse the practice of high-intensity rites without adequate preparation, transmission, and supervision. Stambhana-karma is an *ugra*-category ṣaṭ-karma that arrests a hostile force's capacity to act, and the textual tradition uniformly restricts the operative mantra to practitioners who have received prior *mantra-dīkṣā* in an authorised Śaiva-Śākta lineage. The standalone ṣaṭ-karma category is textually distinct from the Bagalāmukhī Mahāvidyā sādhana catalogued in *bagalamukhi-sadhana.md*, though the two overlap in their operational signature.
