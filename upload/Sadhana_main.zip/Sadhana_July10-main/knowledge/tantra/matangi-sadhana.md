---
title: Mātaṅgī Sādhana
category: Śākta
subcategory: "Mahāvidyā (tenth) — Ucchiṣṭa-Caṇḍālinī / goddess of leftover & transgressive offerings"
tradition: Śākta-Tantra (Mahāvidyā / Dasa-Mahāvidyā)
language: "Sanskrit + Hindi"
century: "Medieval (c. 9th–14th c.); digest literature c. 16th–19th c."
tags: [shakta, mahavidya, matangi, ucchista, chandalini, transgressive, vira-acara, tantra-sarasvati]
caution_level: high
source: "Web-researched, scholarly attested"
---

# Mātaṅgī Sādhana

> The tenth of the Daśa Mahāvidyās, Mātaṅgī (also "Ucchiṣṭa-Caṇḍālinī", "Rāja-Mātaṅgī", "Śyāmā") is the tantric form of Sarasvatī — a green-dark-complexioned goddess offered leftover food (*ucchiṣṭa*) from stained hands, the goddess of speech, music, and the periphery. High caution — an antinomian Mahāvidyā rite whose core offering frame deliberately violates Brahminical purity codes. Preserved here as heritage / source material. Not instructional.

---

## I. Textual Attestation

- **Primary text:** *Mātaṅgī Tantra* (independent Śākta Tantra, surviving through digests); *Gandharva Tantra* (ed. Ramchandra Kak & Harabhatta Shastri, Srinagar, 1934 — a Śākta Tantra with substantial Mātaṅgī / Śyāmā material); *Śākta Praamoda* (Rājadevanandan, Banaras, 19th c.).
- **Secondary text(s):** *Mahāvidyā Tantra Sāra*; *Mantra Mahodadhi* of Mahīdhara; *Śāradā Tilaka* (in the Mahāvidyā chapter); *Devī-Bhāgavata Purāṇa* 3.5.
- **Key scholarship:** David Kinsley, *Tantric Visions of the Divine Feminine: The Ten Mahāvidyās* (University of California Press, 1997); David Gordon White, *Kiss of the Yoginī* (Chicago, 2003); Sanjukta Gupta & Teun Goudriaan, *Hindu Tantric and Śākta Literature* (Harrassowitz, 1981).
- **Source URL (archive):**
  - *Gandharva Tantra*, ed. Ramchandra Kak and Harabhatta Shastri (Srinagar, 1934) on Internet Archive: https://archive.org/details/GandharvaTantra
  - *Gandharva Tantram* (Jangamwadi Math Collection, Kak & Shastri) on Internet Archive: https://archive.org/details/FJBK_gandharva-tantram-by-ram-chandra-kak-and-harabhatta-shastri-jangamwadi-math-collection
  - *Mātaṅgī Mahāvidyā* (Goswami Prahlad Giri, Sanskrit & Hindi) on Internet Archive: https://archive.org/details/matangi-mahavidya
  - *Śākta Praamoda* on Internet Archive: https://archive.org/details/shakta-pramod
  - Kinsley, *Tantric Visions of the Divine Feminine* on Internet Archive: https://archive.org/details/tantricvisionsof0000kins
  - Wisdom Library entry on Mātaṅgī: https://www.wisdomlib.org/definition/matangi

Mātaṅgī is the tenth Mahāvidyā in the canonical list of the *Todala Tantra* and in the *Śākta Praamoda*. Her independent Tantra — the *Mātaṅgī Tantra* — survives chiefly through the recension embedded in Śākta digest literature; the *Gandharva Tantra* (Kak & Shastri 1934 edition, digitised on the Internet Archive) is the most accessible published primary source giving Mātaṅgī's dhāraṇā, bīja, and homa procedure within a single textual witness. The *Śākta Praamoda* of Rājadevanandan, also digitised on the Internet Archive, reproduces the standard paddhati.

Kinsley's 1997 monograph *Tantric Visions of the Divine Feminine* devotes a chapter to Mātaṅgī (pp. 208–222 of the UC Press edition), reading her as the *Tantric Sarasvatī* — the goddess of speech, music, and inner knowledge whose distinctively Śākta feature is the *ucchiṣṭa* (leftover-food) offering frame. Kinsley documents the textual and ethnographic evidence that the goddess is to be offered food that has been partially eaten, from the practitioner's stained hands and mouth, in deliberate inversion of Brahminical *śauca* codes. White (2003, esp. pp. 200–218) places the *ucchiṣṭa*-frame in the wider Śākta-Kaula context of *vīrācāra* antinomianism, where the violation of purity codes is itself the ritual act.

Goudriaan and Gupta (1981) catalogue the *Gandharva Tantra* among the Śākta Tantras with substantial Śyāmā/Mātaṅgī material, and note its textual relation to the *Mātaṅgī Tantra*. The Wisdom Library entry on Mātaṅgī (citing the *Śākta Praamoda* tradition) describes her as the "Tantric form of Sarasvatī" and the goddess of "supernatural powers, especially gaining control over enemies" — a reading consistent with the paddhati literature.

---

## II. Iconography (per sources)

According to the dhāraṇā preserved in the *Śākta Praamoda* and in the *Gandharva Tantra* (Kak & Shastri 1934), Mātaṅgī is described as dark or emerald-green-complexioned (*śyāmā* or *haritābha*), youthful but with the marks of an outcaste — dishevelled hair, sweat-stained garments, ornamented with garlands of *mālatī* flowers, holding in her four arms a noose (*pāśa*), an elephant-goad (*aṅkuśa*), a sugarcane-bow (*ikṣu-kodaṇḍa*), and a lotus or a skull-cup. She is seated on a throne or on a corpse (*śava*), depending on the recension. Her eyes are described as bloodshot or deep-red.

The commentary tradition, summarised by Kinsley (1997, pp. 209–213), records two principal forms: (i) *Rāja-Mātaṅgī* — the royal form, green-complexioned, four-armed, playing the *vīṇā*, attended by parrots; and (ii) *Ucchiṣṭa-Caṇḍālinī* — the antinomian form, dark-red or smoke-coloured, seated on a corpse, holding skull-cup and chopper, ornamented with the emblems of the cremation ground. The *Ucchiṣṭa-Caṇḍālinī* form is the one most strongly associated with the Mahāvidyā cycle's transgressive offering frame. The *Gandharva Tantra*'s Śyāmā-paddhati (chapters 1–4 of the Kak & Shastri edition) gives the most extensive textual witness of the *Ucchiṣṭa-Caṇḍālinī* form's dhāraṇā.

The Wisdom Library entry, citing the *Śākta Praamoda* tradition, notes that Mātaṅgī is offered *ucchiṣṭa* (leftover food) from the practitioner's stained hands and mouth — a deliberate inversion of Brahminical purity codes. This is the iconographic-ritual feature that distinguishes her from Sarasvatī: where Sarasvatī is offered fresh white flowers by pure-handed Brahmans, Mātaṅgī is offered the *ucchiṣṭa*-remnant by the practitioner in a state of intentional ritual impurity. The goddess is associated with the periphery of society — with the outcaste (*caṇḍāla*), the *Śyāmā* dark-complexioned caste, the forest, the margin — and with the *vāk*-power (speech) that operates beyond sanctioned ritual channels.

---

## III. Mantra & Method (as documented in sources)

> **Editorial note.** The mantra and method below are reproduced from published textual sources for scholarly preservation. This is documentation, not instruction.

- **Bīja mantra:** The mūla-mantra is documented in the *Śākta Praamoda*, in the *Gandharva Tantra* (Kak & Shastri 1934 edition), and in the Goswami Prahlad Giri *Mātaṅgī Mahāvidyā*. The exact form varies across textual lineages; the publicly attested bīja-frame incorporates the *hūṃ* / *hrīṃ* / *aiṃ* phonemes — the latter (*aiṃ*) being the Sarasvatī-bīja retained from her Vaidika-cognate tradition — prefixed to the goddess's name-bīja, with the *phaṭ* termination. The specific mūla-mantra is dīkṣā-restricted in published editions; the per-recension exact form is not reproduced here.
- **Mantra count:** Paddhati literature documents puraścaraṇa counts in multiples of 10,000; the *Gandharva Tantra* records a structural count for the Śyāmā-paddhati.
- **Duration:** Puraścaraṇa cycles of 21 / 41 / 45 days are documented in the *Śākta Praamoda* and the *Mātaṅgī Mahāvidyā*.
- **Direction facing:** East or North, per paddhati convention (Mātaṅgī's directional association is *pūrva* / *uttara* — east or north — in contrast to the ugra-Mahāvidyās who face south or south-west).
- **Mālā:** *Sphaṭika* (rock-crystal) or *viḍṅga*-seed mālā; the textual witnesses vary.

The procedure documented in the *Gandharva Tantra* and the *Śākta Praamoda* opens with the standard nyāsa sequence followed by the dhāraṇā of the goddess, japa of the mūla-mantra on the prescribed mālā, and homa of green or dark-coloured flowers, *bilva*-leaves, and *naivedya* of *ucchiṣṭa*-food (leftover from the practitioner's own meal) into a triangular kuṇḍa. The *Śyāmā-paddhati* of the *Gandharva Tantra* (Kak & Shastri 1934) is the most extensive single textual witness of the procedure.

The defining ritual feature, attested in Kinsley (1997) and confirmed by the *Śākta Praamoda*, is the *ucchiṣṭa*-offering: the practitioner offers the goddess food that has been partially eaten, from stained hands and mouth. This is the *vīrācāra*-frame offering that textual tradition treats as the operational core of the practice. White (2003) reads this within the broader Śākta-Kaula antinomian frame, in which the violation of purity codes is itself the ritual act by which the goddess is invoked.

---

## IV. Yantra (if attested)

A yantra is described in the *Śākta Praamoda* and in the *Mātaṅgī Mahāvidyā*. It consists of a square *bhūpura* with four gates, enclosing a sixteen-petalled lotus (*ṣoḍaśadala-padma*), which in turn encloses an eight-petalled lotus housing the goddess's bīja at the centre and the bījas of her four attendants at the cardinal points. The central figure is a downward-pointing triangle (*adho-mukha-trikoṇa*) inscribed with the goddess's name-bīja. The yantra is described as inscribed on green silk or on *bhūrja* (birch-bark) using a paste of *kuṅkuma*, *gorocanā*, and green *haritāla* powder. Specific bīja placements are documented in the *Śākta Praamoda* and are not reproduced in detail here.

---

## V. Warnings and Contraindications (per sources)

- The *Śākta Praamoda* paddhati literature explicitly restricts the Mātaṅgī mūla-mantra to practitioners who have received dīkṣā in an authorised Śākta lineage; the *ucchiṣṭa*-offering frame is uniformly described as a *vīrācāra* practice, not to be undertaken by householders of Brahminical orientation.
- Kinsley (1997, pp. 215–222) discusses the deliberate ritual inversion that the practice encodes: the textual tradition cautions that the practice requires the practitioner to have internalised the antinomian stance of *vīrācāra*, in which the conventional polarity of pure/impure is dissolved prior to the offering. Without this preparation, the *ucchiṣṭa*-offering is described in the paddhati literature as fruitless at best and harmful at worst.
- The *Gandharva Tantra*'s Śyāmā-paddhati records dietary and purity observances for the duration of the puraścaraṇa that are themselves antinomian: the practitioner is to take food without restriction, to eat at irregular hours, and to wear garments that have not been washed — features that distinguish the practice from the *daśācāra*-Brahminical framework.
- White (2003) situates the *ucchiṣṭa*-frame within the broader Śākta-Kaula context, and notes that the textual tradition warns against the practice being undertaken without the supervision of a *guru* who has himself completed the *vīrācāra*-purification.
- The Hindu Mātaṅgī tradition has no exact Brahminical parallel; her worship is uniformly Śākta-Tantric and dīkṣā-gated.

---

## VI. Bibliography

1. Kinsley, David. *Tantric Visions of the Divine Feminine: The Ten Mahāvidyās.* Berkeley: University of California Press, 1997. (See esp. the Mātaṅgī chapter, pp. 208–222.) Internet Archive: https://archive.org/details/tantricvisionsof0000kins
2. White, David Gordon. *Kiss of the Yoginī: "Tantric Sex" in Its South Asian Contexts.* Chicago: University of Chicago Press, 2003. (See esp. pp. 200–218 on the *ucchiṣṭa*-frame in Śākta-Kaula antinomianism.)
3. Goudriaan, Teun, and Sanjukta Gupta. *Hindu Tantric and Śākta Literature.* Wiesbaden: Otto Harrassowitz, 1981.
4. *Gandharva Tantra*, ed. Ramchandra Kak and Harabhatta Shastri. Srinagar, 1934. Internet Archive: https://archive.org/details/GandharvaTantra
5. *Gandharva Tantram* (Jangamwadi Math Collection). Internet Archive: https://archive.org/details/FJBK_gandharva-tantram-by-ram-chandra-kak-and-harabhatta-shastri-jangamwadi-math-collection
6. *Mātaṅgī Mahāvidyā* (Goswami Prahlad Giri, Sanskrit & Hindi). Internet Archive: https://archive.org/details/matangi-mahavidya
7. *Śākta Praamoda*, compiled by Rājadevanandan. Internet Archive: https://archive.org/details/shakta-pramod
8. Wisdom Library entry on Mātaṅgī: https://www.wisdomlib.org/definition/matangi

---

## Editorial Framing

This document is preserved as part of the AstroKalki knowledge archive for scholarly study. It does not prescribe, recommend, or guarantee outcomes. Readers seeking to undertake the described practice should consult qualified lineage holders and the primary texts directly. The AstroKalki project does not endorse the practice of high-intensity rites without adequate preparation, transmission, and supervision.
